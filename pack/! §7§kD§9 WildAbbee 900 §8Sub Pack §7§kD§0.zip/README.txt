📌 Credits

This resource pack is given to you for free, in order to respect the pack creator, please give us credits, also, do not use this pack for sale nor claim to be its pack maker.


📌 This resource pack was made by FuzniX for WildAbbee.

- WildAbbee is a JartexNetwork and PikaNetwork content creator. 🎥
Here is the link to her YouTube channel, make sure to subscribe!
🔗 https://www.youtube.com/@WildAbbee/

- Want additional content?
Here is the link of my YouTube channel, FuzniX, where I also post JartexNetwork content, go check it out and subscribe! 🎥
🔗 https://www.youtube.com/@fuznix


⚔️ JartexNetwork and PikaNetwork

JartexNetwork and PikaNetwork are 2 Minecraft servers that propose a lot of gamemodes, both propose Bedwars for which this resource pack is.
Join us with these IP addresses!
🔗 JartexNetwork: play.jartexnetwork.com (jartex.fun)
🔗 PikaNetwork: play.pika-network.net (pika.host)


📌 Textures

Most of the textures were taken from different PvP resource packs, I do not own nor claim to own these textures, here are the packs I took textures from:
- spirit 16x by emmalynpacks
- NicoFruit 16x by keno
- HypFault 16x by keno
- WildAbbee - 350 Sub Pack
- Nebulite 20x by FuzniX
- nebula 32x by looshy
- Penguin 16x by Pranksterman & BossBunny
- BetterVanillaBuildingV2.37 by StefanJ2_
- Kysiek 10K 32x by Hydrogenate
- Chroma Lite 32x by NotroDan
- Connected Clay Textures by Liquify
- SammyFault 16x by keno
- Shade 64x by MathoX
- Default 1.14 textures by Mojang
- And others I might have forgotten!